Autocompletion avanc�e en ajax -------------------------------
Url     : http://codes-sources.commentcamarche.net/source/40439-autocompletion-avancee-en-ajaxAuteur  : younes371Date    : 14/08/2013
Licence :
=========

Ce document intitul� � Autocompletion avanc�e en ajax  � issu de CommentCaMarche
(codes-sources.commentcamarche.net) est mis � disposition sous les termes de
la licence Creative Commons. Vous pouvez copier, modifier des copies de cette
source, dans les conditions fix�es par la licence, tant que cette note
appara�t clairement.

Description :
=============

Bonjour,
<br />Voil&agrave; en surfant sur le Net j'ai trouv&eacute; un exemple
 super
<br />qui montre l'utilisation d'AutoCompletion (Resultat avec mot et im
age !).
<br />Pour le code vous le trouvez ici :
<br /><a href='http://www.j0k
3r.net/ajax-une-autocompletion-avancee-en-ajax-6.html' target='_blank'>http://ww
w.j0k3r.net/ajax-une-autocompletion-avancee-en-ajax-6.html</a>
<br />et pour le
 Demo, c'est ici :
<br /><a href='http://www.j0k3r.net/exemples/ajax/autocomple
tion.php' target='_blank'>http://www.j0k3r.net/exemples/ajax/autocompletion.php<
/a>
<br /><a name='source-exemple'></a><h2> Source / Exemple : </h2>
<br /><p
re class='code' data-mode='basic'>
d'autres exemple ici :
<a href='http://dcab
asson.developpez.com/articles/javascript/ajax/ajax-autocompletion-pas-a-pas/' ta
rget='_blank'>http://dcabasson.developpez.com/articles/javascript/ajax/ajax-auto
completion-pas-a-pas/</a>

<a href='http://www.i-marco.nl/demo_en/demonstratie
4.php' target='_blank'>http://www.i-marco.nl/demo_en/demonstratie4.php</a> =&gt;
 utilise la librairie XAJAX

Bonne chance
</pre>
